#!/usr/bin/env python3
# Aaron Bevans, 3/10/24 
# comparing programming languages
# application that outputs "Hello, World!"
# above line ensures that the script will run smoothly across different environments.
print("Hello, World!")
