//Aaron Bevans, 3/10/24 
//comparing programming languages
//application that outputs "Hello, World!"

/*
    stands for standard input-output stream.
    declares objects that control reading from and 
    writing to standard streams.
*/
#include <iostream> 

//can use names for objects and variables from standard library.
using namespace std;
// method contains all data that is output.
int main(){
    //string to be output.
    cout << "Hello, World!";
}